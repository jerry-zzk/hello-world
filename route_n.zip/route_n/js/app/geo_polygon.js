define([
	'backbone',
	'common',
	'ol'
], function(Backbone, urls, ol) {
	var geo_polygon = Backbone.View.extend({
		el: '#map',
		initialize: function(map, name) {
			
			this.map = map;
			window.map = map;
			this.name = (name !== undefined && name !== null) ? name : "湖南省";
			this.vector = "";
			
			this.render();
		},
		render: function() {
			this.remove();
			var name = this.name;
			this.vector = new ol.layer.Vector({
				title: "geo_polygon",
				source: new ol.source.Vector({
					loader: function(){
				        var url = urls.get_geopolygon + "name=" + name
				        var format = new ol.format.GeoJSON();
				        var source = this;
				        $.get(
				        	url,
				        	function(data){
				        		var features = format.readFeatures(data, {
				                    featureProjection: 'EPSG:3857'
				                });
				                source.addFeatures(features);
				                map.getLayers().forEach(function(e, i) {
									
									if(e.get("title") == 'geo_polygon'){								
										map.getView().fit(e.getSource().getExtent(),this.map.getSize());										
									}
								});
				        	},
				        	'json'
				        );				       
				    }
				}),
				
			});
			
			this.map.addLayer(this.vector);

			
			// this.vector.on('precompose', function(e) {
			//   e.context.globalCompositeOperation = 'destination-in';
			// });
			
		},
		remove: function() {
			map.getLayers().forEach(function(e, i) {
				if(e.get("title")){	
					//console.log("delete polygon");
					map.removeLayer(e);
				}
			});
		}
	});
	return geo_polygon;
})