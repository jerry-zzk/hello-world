define([
    'backbone',
    'common',
    'ol',
    'ol3',
    'bootstrap',
    'cluster',
    'select_cluster'
], function (Backbone, urls, ol, ol3,bootstrap) {
    var heat = Backbone.View.extend({

        el: '#map',
        initialize: function (map, start_time, end_time, name, id, phone, type){

            //debugger;
            window.urls = urls;
            window.ol = ol;  
            this.map = map;
            this.name = (name !== undefined && name !== null) ? name : "湖南";

            this.node_id = (id != undefined && id != null) ? id : "";
            this.type = (type != undefined && type != null) ? type : "";
            this.phone = (phone != undefined && phone != null) ? phone : "";
            this.$el.append('<div id="popup"></div>');
            window.element =  document.getElementById('popup');

            window.popup = this.popup = new ol.Overlay({
                element: window.element,
                positioning: 'bottom-center',
                stopEvent: false,
                offset: [0, -10]
            });
0
            this.map.removeOverlay(this.popup);
            this.map.addOverlay(this.popup);

            $(this.element).popover('destroy');
            if (start_time !== undefined && start_time !== null && end_time !== undefined && end_time !== null) {

                this.st = start_time;
                this.ed = end_time;
                //

                this.render();

            } else {
                this.re();
            }
            //this.map_move(this);

        },
        re: function () {
            function refresh(th){

                //console.log(th);

                th.ed = end_time = parseInt(new Date().getTime()/1000);
                th.st = start_time = end_time - 5*60;
                //th.ed = 1482229300;
                //th.st = 1482229100;

                //
                // th.$el.append('<div id="popup"></div>');
                // window.element = th.element = document.getElementById('popup');

                // window.popup = th.popup = new ol.Overlay({
                //     element: th.element,
                //     positioning: 'bottom-center',
                //     stopEvent: false,
                //     offset: [0, -10]
                // });

                // th.map.removeOverlay(th.popup);
                // th.map.addOverlay(th.popup);
                //$(th.element).popover('destroy');


                th.render();
            }
            refresh(this);
            setInterval(refresh,1000*3000,(this));
        },
        render: function () {

            var name = this.name;

            var node_id = this.node_id;
            var phone = this.phone;
            var type = this.type;

            var st = this.st;
            var ed = this.ed;

            //debugger;
            $.get(
                urls.get_centerpoint + "name=" + this.name,
                function (data) {
                    if (data.status == 0) {
                        map.setView(new ol.View({
                            center: ol.proj.fromLonLat([data.lng, data.lat]),
                            zoom: 10
                        }));
                    } else {
                        map.setView(new ol.View({
                            center: [12580502.955858162, 3273023.9965427117],
                            zoom: 10
                        }));
                    }
//debugger;
                    var urls = window.urls.get_station + "name=" + name + "&starttime=" + st + "&endtime=" + ed;

                    if (node_id != "") {
                        urls = urls + "&id=" + node_id;
                    }
                    if (phone != "") {
                        urls = urls + "&phone=" + phone;
                    }
                    if (type != "") {
                        urls = urls + "&type=" + type;
                    }

                    var extent1 = ol.proj.toLonLat(map.getView().calculateExtent(map.getSize()));
                    var extent2 = ol.proj.toLonLat(map.getView().calculateExtent(map.getSize()).slice(-2));


                    urls = urls + "&latstart=" + extent1[1] +
                        "&latend=" + extent2[1] +
                        "&lngstart=" + extent1[0] +
                        "&lngend=" + extent2[0];


                    var vectorLayer = new ol.layer.Vector({
                        title: "geo_polygon",
                        source: new ol.source.Vector({
                            loader: function () {
                                var url = urls;
                                var format = new ol.format.GeoJSON();
                                var source = this;
                                $.get(
                                    url,
                                    function (data) {
                                        var features = format.readFeatures(data,{
                                            featureProjection: 'EPSG:3857'
                                        });
                                        source.addFeatures(features);
                                    },
                                    'json'
                                );
                            }
                        }),
                        style: function (feature) {
                            if (feature.getGeometry().getType() === 'Point') {
                                if (feature.get("type") == 2){
                                    if (feature.get("c_fbs_status") == 0){
                                        feature.setStyle(new ol.style.Style({
                                            image: new ol.style.Icon({
                                                anchor: [0.5, 1],
                                                src: '/route/image/is_close.png'
                                            })
                                        }));
                                    } else {
                                        feature.setStyle(new ol.style.Style({
                                            image: new ol.style.Icon({
                                                anchor: [0.5, 1],
                                                src: '/route/image/is_open.png'
                                            })
                                        }));
                                    }
                                } else {

                                    feature.setStyle(new ol.style.Style({
                                        image: new ol.style.Icon({
                                            anchor: [0.5, 0.5],
                                            src: '/route/image/point.gif'
                                        })
                                    }));

                                }
                            } else {
                                if (feature.get("type") == 2) {
                                    feature.setStyle(new ol.style.Style({
                                        stroke: new ol.style.Stroke({
                                            color: 'rgba(7,36,49,0.5)',
                                            lineCap: 'round',
                                            lineJoin: 'round',
                                            width: 5
                                        })
                                    }));
                                } else {
                                    feature.setStyle(new ol.style.Style({
                                        stroke: new ol.style.Stroke({
                                            color: 'rgba(34,180,235,0.5)',
                                            lineCap: 'round',
                                            lineJoin: 'round',
                                            width: 5
                                        })
                                    }));
                                }
                            }
                        }
                    });
                    //map.addLayer(vectorLayer);
                },
                'json'
            );

            var ma = document.getElementById("main");
            ma.style.display = "block";
            var menu_overlay = new ol.control.Control({
                element: ma
            });
            menu_overlay.setMap(map);

            var an = document.getElementById("anniu");
            an.style.display = "block";
            var menu_overlay1 = new ol.control.Control({
                element: an
            });
            menu_overlay1.setMap(map);

            var an1 = document.getElementById("anniu2");
            an1.style.display = "block";
            var menu_overlay2 = new ol.control.Control({
                element: an1
            });
            menu_overlay2.setMap(map);

            //    列表

            var l = document.getElementById("list");
            l.style.display = "block";

            var fa = false;
            $.get(
                urls.get_AllFigure,
                {code:name},
                    function(data){

                        var c = JSON.parse(data);
                        var len = c.length;

                        if(len>9){
                            l.style.height = "300px";
                            $("#list").css("overflow-y","scroll");
                            $("#list").css("overflow-x","hidden");
                        }

                    for (var n = 0; n < len; n++){
                        //获取div
                        var div = document.getElementById("list");
                        var div2 = document.createElement("option");
                        div2.className = "list-group-item";

                        //拿到保存的名字
                        div2.innerText = c[n].name;
                        var did = c[n].id;
                        div2.text = div2.innerText;
                        div2.value = did;
                        div.appendChild(div2);
                        l.appendChild(div2);

                        var coor = c[n].coordinate;

                        div2.addEventListener("click", function(){

                            fa = true;


//                      每次点击先清空所有的layer
                            var le =  map.getLayers().array_.length;
                            if(le > 1){
                                map.removeLayer(map.getLayers().array_[1]);
                                map.removeLayer(map.getLayers().array_[2]);
                            }
                            console.log(le);

                            var b = document.getElementById("baoliu");
                            b.value = this.value;

                            var of = $(this).index();
                            var coord = c[of].coordinate;
                            var ar = coord.split(";");
                            var arr = [];
                            ar.forEach(function(e){
                                var a = e.split(",");
                                var x = ol.proj.fromLonLat([parseFloat(a[0]),parseFloat(a[1])]);
                                arr.push(x);
                            });
                            // console.log(arr);

                            //debugger;
                            //还原多边形
                            var fea = new ol.Feature({
                                geometry: new ol.geom.Polygon([arr])
                            });
                            var vec = new ol.layer.Vector({
                                source:new ol.source.Vector(),
                                style:function(fea){
                                    return new ol.style.Style({
                                        fill: new ol.style.Fill({
                                            color: 'rgba(255, 255, 255, 0.4)'
                                        }),
                                        stroke: new ol.style.Stroke({
                                            color: '#ffcc33',
                                            width: 2
                                        }),
                                        image: new ol.style.Circle({
                                            radius: 7,
                                            fill: new ol.style.Fill({
                                                color: '#ffcc33'
                                            })
                                        })
                                    })
                                }
                            });

                            vec.getSource().addFeature(fea);
                            map.addLayer(vec);

                            // debugger
                            // 定位zoom
                            map.getView().fit(vec.getSource().getExtent(), map.getSize());


                            // map.setView(
                            //     new ol.View({
                            //         center: arr[3],
                            //         zoom: 11
                            //     })
                            // );



                        }, false);
                    }
                }
            );

            var jian = ed - st;
            var pri = 60*5;
            var chu = parseInt(jian/pri);
            for(var i = 1; i < chu; i++){
                $('.ad-list').append('<li><a>'+i+'</a></li>');
                $('.ad-wrap').css("border","2px solid #FF7F00");
            }

            timeBase({
                wrap:$('.ad-wrap'),
                list:$('.ad-wrap').find(".ad-list"),
                length: $('.ad-wrap').find(".ad-list li"),  
                btn:$('#anniu'),
                btn1:$('#anniu2')
            });
            function timeBase(option) {

                var $wrap =  option.wrap;
                var $list = option.list;
                var $len =  option.length;
                var $btn =  option.btn;
                var $btn1 =  option.btn1;

                var iNow = 0;
                var timer = null;
                var len = $len.length;
                var iW = parseInt($wrap.width()+4 +"px");  
                var a = 0;

                //alert(iW);
                $btn.click(
                    function () {
                        if(fa){
                            autoPlay();
                        }
                    }
                );
                $btn1.click(
                    function () {
                        clearInterval(timer);
                    }
                );
                function toNext(){
                    changeView();
                    iNow++;
                    if(iNow>=len){
                        iNow=0;
                    }
                }
                function autoPlay() {
                    timer = setInterval(toNext,2000);
                }
                function changeView() {
                    var c =  $list.find('a').removeClass("active").eq(iNow).addClass("active");

                    //清除热力点
                    var le =  map.getLayers().array_.length;
                    if(le > 1){
                        map.removeLayer(map.getLayers().array_[2]);
                        map.removeLayer(map.getLayers().array_[3]);
                    }
                    console.log(le);

                    if(c){
                        var b = document.getElementById("baoliu");
                        //    热力图
                        var heatmap = new ol.layer.Heatmap({
                            source: new ol.source.Vector({
                                loader: function () {
                                    var format = new ol.format.GeoJSON();
                                    var source = this;
                                    var ba = parseInt(st) +parseInt( (c.text()- 1)* pri);
                                    var ma = parseInt(st) +parseInt( (c.text())* pri);
                                    //console.log(ba);
                                    //console.log(ma);
                                    $.get(
                                        urls.get_Heat,
                                        {
                                            id: b.value,
                                            starttime:ba,
                                            //starttime:st,
                                            //endtime:ed,
                                            endtime:ma,
                                            period:pri
                                        },
                                        function (data) {

                                            //处理数据
                                            //$.each(data.features,function(i,e){
                                            //    var ca = e.properties.TimePeriod;//周期
                                            //    if(ca > ba-1 && ca < ma+1){
                                            //        console.log("这个点在当前周期中");
                                            //    }else{
                                            //        console.log("这个点不在当前周期中");
                                            //    }
                                            //});

                                            //console.log(data);
                                            //debugger;
                                            var max = 0;
                                            //console.log(data);
                                            $.each(data.features,function(i,e){
                                                var a = e.properties.UliCount;
                                                if(a>max){
                                                    max = a;
                                                }
                                            });

                                            //console.log(max);
                                            $.each(data.features,function(i,e){

                                                e.properties.weight = e.properties.UliCount/max;
                                                //e.properties.weight =  e.properties.weight.toFixed(2);

                                                if(e.properties.UliCount > 500){
                                                    e.properties.weight =  1;
                                                }
                                                //e.properties.weight =  0.5;

                                            });
                                            //
                                            var features = format.readFeatures(data, {
                                                featureProjection: 'EPSG:3857'
                                            });
                                            source.addFeatures(features);

                                        },
                                        "json"
                                    );
                                }
                            })
                        });

                        map.addLayer(heatmap);

                        //heatmap.setOpacity();
                        //var source = heatmap.getSource();
                        //var heatmap =heatmap;
                        //var features = source.getFeatures();
                        //features.forEach(function(e){
                        //    source.removeFeature(e);
                        //    heatmap.animateFeature(e,[
                        //            new ol.featureAnimation['Fade']({
                        //                speed:0.8,
                        //                duration:2000,
                        //                side:false,
                        //                revers:true
                        //            })
                        //        ]
                        //    );
                        //});


                        //var c = heatmap.getSource();
                        //console.log(c);
                        //if(){
                        //
                        //}

                    }
                    $list.stop().animate({"left":-iNow * iW});
                    //console.log(a++);
                }
            }
        },
        remove:function(){
            map.getLayers().forEach(function (e, i) {
                map.removeLayer(e);
            });
        }
    });
    return heat;
});