define([
    'backbone',
    'common',
    'ol',
    'bootstrap',
    'cluster',
    'select_cluster'
], function (Backbone, urls, ol, bootstrap) {
    var heatmap = Backbone.View.extend({


        el: '#map',
        initialize: function (map, name, start_time, end_time, id, phone, type){

            //debugger;
            window.urls = urls;
            window.ol = ol;
            this.map = map;
            this.name = (name !== undefined && name !== null) ? name : "湖南";

            this.node_id = (id != undefined && id != null) ? id : "";
            this.type = (type != undefined && type != null) ? type : "";
            this.phone = (phone != undefined && phone != null) ? phone : "";
            this.$el.append('<div id="popup"></div>');
            window.element =  document.getElementById('popup');


            window.popup = this.popup = new ol.Overlay({
                element: window.element,
                positioning: 'bottom-center',
                stopEvent: false,
                offset: [0, -10]
            });

            this.map.removeOverlay(this.popup);
            this.map.addOverlay(this.popup);

            $(this.element).popover('destroy');
            if (start_time !== undefined && start_time !== null && end_time !== undefined && end_time !== null) {

                this.st = start_time;
                this.ed = end_time;
                //

                this.render();

            } else {
                this.re();
            }
            //this.map_move(this);
        },
        re: function () {
            function refresh(th){

                //console.log(th);
                th.ed = end_time = parseInt(new Date().getTime()/1000);
                th.st = start_time = end_time - 5*60;
                //th.ed = 1482229300;
                //th.st = 1482229100;

                //
                // th.$el.append('<div id="popup"></div>');
                // window.element = th.element = document.getElementById('popup');

                // window.popup = th.popup = new ol.Overlay({
                //     element: th.element,
                //     positioning: 'bottom-center',
                //     stopEvent: false,
                //     offset: [0, -10]
                // });

                // th.map.removeOverlay(th.popup);
                // th.map.addOverlay(th.popup);
                //$(th.element).popover('destroy');


                th.render();
            }
            refresh(this);
            setInterval(refresh,1000*3000,(this));
        },
        render: function () {

            var name = this.name;

            var node_id = this.node_id;
            var phone = this.phone;
            var type = this.type;

            //
            var st = this.st;
            var ed = this.ed;

            //debugger;
            $.get(
                urls.get_centerpoint + "name=" + name,
                function (data) {
                    if (data.status == 0) {
                        //console.log(124);
                        //console.log(data);
                        map.setView(new ol.View({
                            center: ol.proj.fromLonLat([data.lng, data.lat]),
                            zoom: 10
                        }));
                        //console.log(ol.proj.fromLonLat([data.lng, data.lat]));
                    } else {
                        map.setView(new ol.View({
                            center: [12580502.955858162, 3273023.9965427117],
                            zoom: 10
                        }));
                    }
                },
                'json'
            );

            //绘制图形
            var source = new ol.source.Vector();
            var vector = new ol.layer.Vector({
                source: source,
                style: new ol.style.Style({
                    fill: new ol.style.Fill({
                        color: 'rgba(255, 255, 255, 0.4)'
                    }),
                    stroke: new ol.style.Stroke({
                        color: '#ffcc33',
                        width: 2
                    }),
                    image: new ol.style.Circle({
                        radius: 7,
                        fill: new ol.style.Fill({
                            color: '#ffcc33'
                        })
                    })
                })
            });
            vector.setMap(map);

            //绘制
            var f = document.getElementById("fo");
            f.style.display = "block";
            var menu_overlay = new ol.control.Control({
                element: f
            });

            menu_overlay.setMap(map);

            //列表
            var l= document.getElementById("list");

            var li = new ol.control.Control({
                element: l
            });

            li.setMap(map);

            var l = document.getElementById("list");
            l.style.display = "block";

            //
            var t = document.getElementById("tc");
            var tc = new ol.control.Control({
                element: t
            });
            tc.setMap(map);

            var draw;
            var old_feature;
            var typeSelect = document.getElementById('type');
            function addInteraction() {
                draw = new ol.interaction.Draw({
                    source: source,
                    type: typeSelect.value
                });

                //画完下一个图后 删除之前画的图形
                //draw.on('drawstart',
                draw.on('drawend',
                    function(evt) {
                    // set old_feature
                    if(old_feature != null && old_feature != "undifined"){
                        //删除前一个图层
                        source.removeFeature(old_feature);
                    }
                    old_feature = evt.feature;
                }, this);
                map.addInteraction(draw);
            }

            typeSelect.onchange = function(){
                map.removeInteraction(draw);
                addInteraction();
            };
            addInteraction();

           // // 绑定键盘esc事件
           // $(document).keyup(function(event){
           //     switch(event.keyCode) {
           //         case 27:
           //             alert("ESC");
           //             //if(old_feature!=null && old_feature!="undifined"){
           //             //    //删除前一个图层
           //             //    source.removeFeature(old_feature);
           //             //};
           //     }
           // });

            //右键
            var menu_overlay1 = new ol.Overlay({
                element: document.getElementById("tc"),
                positioning: 'center-center'
            });
            menu_overlay1.setMap(map);
            $(map.getViewport()).on("contextmenu", function(event){

                    var c = document.getElementById("tc");
                    c.style.display = "block";

                    var inp = document.getElementById("inp");
                    inp.value = "";

                    //点击保存之后 然后把画笔清除
                    map.removeInteraction(draw);
                    addInteraction();

                    //var pixel = map.getEventPixel(event.originalEvent);//获取鼠标当前像素点
                    //console.log(pixel);
                    //var hit = map.hasFeatureAtPixel(pixel);//通过像素点判断当前鼠标上是否有图形
                    //console.log(hit);

                    var coordinate = map.getEventCoordinate(event);//获取鼠标坐标
                    //console.log(coordinate);

                    event.preventDefault();//阻止右键默认事件

                    menu_overlay1.setPosition(coordinate);
                    //console.log(menu_overlay1);
            });
            $(map.getViewport()).on("click", function(e){

                e.preventDefault();

                menu_overlay1.setPosition(undefined);
            });

            //点击保存
           var s = document.getElementById("cun");
            s.onclick = function(){


                function showCoordinate(){
                    //var features = source.getFeatures();
                    var features = vector.getSource().getFeatures();
                    //console.log(features.length);
                    if (features != null && features.length > 0){
                        for (var x in features){
                            var geom = features[x].getGeometry(); //Geometry

                            if(typeSelect.value == "Polygon"){  //如果是多边形 获取 各个点坐标
                                var c = geom.getCoordinates();

                                var ad = [];
                                for(var i = 0;i<c[0].length;i++){
                                   var b =  ol.proj.toLonLat(c[0][i]);
                                    ad.push(b);
                                }

                                var coo = ad.join(";");
                                var js = JSON.stringify(coo);

                                $.get(
                                    //url,
                                    urls.set_Figure,
                                    {
                                        coordinate:js,
                                        name:document.getElementById("inp").value,
                                        code:name
                                    },
                                    function(data){

                                        var c = JSON.parse(data);
                                        var stat = c.status;
                                        //console.log(c.name);
                                        if(stat == -1){
                                            alert(c.info + ","+"请重新输入");
                                            var inp = document.getElementById("inp").value;
                                            inp = '';
                                        }
                                        else if(status == 0){

                                            var inp = document.getElementById("inp").value;
                                            //alert(inp);
                                            var option = document.createElement("option");
                                            option.className = "list-group-item";

                                            //alert(option.value);

                                            option.text = c.name;
                                            option.value = c.id;

                                            l.appendChild(option);
                                            //alert(option.value);

                                            //l.style.display = "block";

                                            var chils= l.childNodes;
                                            //console.log(chils.length);
                                            if(chils.length > 9){
                                                l.style.height = "300px";
                                                $("#list").css("overflow-y","scroll");
                                                $("#list").css("overflow-x","hidden");
                                            };

                                            option.addEventListener("dblclick", function(){

                                                var de = document.getElementById("shan");
                                                var di1 = document.getElementById("dian1");
                                                var di2 = document.getElementById("dian2");
                                                de.style.display = "block";
                                                var ti = this.text;
                                                var va = this.value;
                                                var opti = this;
                                                //alert(this.value);
                                                //console.log(ti);
                                                //alert(ti);

                                                di1.addEventListener("click", function(){

                                                    $.post(
                                                        //url,
                                                        //http://127.0.0.1:8080/PBS/delFigure,
                                                        urls.del_Figure,
                                                        {
                                                            name:ti,
                                                            id:va
                                                        }
                                                    );

                                                    opti.remove();

                                                    de.style.display = "none";
                                                    //alert(ti);

                                                    if(chils.length == 0){
                                                        l.style.display = "none";
                                                    }

                                                    if(chils.length < 11 && chils.length > 0 ){
                                                        l.style.height = chils.length * 30+"px";
                                                    }

                                                },false);
                                                di2.addEventListener("click", function(){
                                                    de.style.display = "none";
                                                },false);
                                            }, false);
                                            option.addEventListener("mouseover", function(){
                                                option.title = "双击删除";
                                            }, false);

                                            //alert(chils.length);
                                            if(chils.length < 10 && chils.length > 0 ){
                                                l.style.height = chils.length * 30+"px";
                                            }

                                            t.style.display = "none";
                                            l.style.display = "block";

                                        }
                                    }
                                )

                            } else if(typeSelect.value == "Circle"){ //如果是圆  获取中心点和半径

                                var lonlats = geom.getCenter();
                                //var ce = geom.getExtent();    //当是圆的时候 获取渲染热力图范围
                                var bb = ol.proj.toLonLat(lonlats);
                                var lon = bb.join(',');
                                var jso = JSON.stringify(lon);
                                var r = geom.getRadius();

                                $.get(
                                    //url,
                                    urls.set_Figure,
                                    {
                                        coordinate:jso,
                                        radius:r,
                                        name:document.getElementById("inp").value,
                                        code:name
                                    },
                                    function(data){

                                        var c = JSON.parse(data); 

                                        option.text = c[0].name;
                                        option.value =c[0].id;

                                    }
                                )
                            }
                        }
                    }
                }

                showCoordinate();

            };

            function ge(){
                $.get(
                    urls.get_AllFigure,
                    {
                        code:name
                    },
                    function(data){

                        var c = JSON.parse(data);
                        var len = c.length;

                        if(len>9){
                            l.style.height = "300px";
                            $("#list").css("overflow-y","scroll");
                            $("#list").css("overflow-x","hidden");
                        }

                        for (var n = 0; n < len; n++){
                            //获取div
                            var div = document.getElementById("list");
                            var div2 = document.createElement("option");
                            div2.className = "list-group-item";

                            //拿到保存的名字
                            div2.innerText = c[n].name;
                            var did = c[n].id;
                            div2.text = div2.innerText;
                            div2.value = did;
                            div.appendChild(div2);
                            l.appendChild(div2);
                            var chl = l.childNodes;

                            if(chl.length > 9){
                                l.style.height = "300px";
                                $("#list").css("overflow-y","scroll");
                                $("#list").css("overflow-x","hidden");
                            };

                            div2.addEventListener("dblclick", function(){

                                var de = document.getElementById("shan");
                                var di1 = document.getElementById("dian1");
                                var di2 = document.getElementById("dian2");
                                de.style.display = "block";
                                var ti = this.text;
                                var va = this.value;
                                var zhe = this;
                                //alert(this.value);
                                //console.log(ti);
                                //console.log(zhe);

                                di1.addEventListener("click", function(){

                                    $.post(
                                        //url,
                                        //http://127.0.0.1:8080/PBS/delFigure,
                                        urls.del_Figure,
                                        {
                                            name:ti,
                                            id:va
                                        }
                                    );
                                    zhe.remove();
                                    //console.log(zhe);

                                    de.style.display = "none";
                                    //alert(ti);
                                    //alert(chl.length);
                                    //alert(zhe.index);

                                    //console.log(chl);
                                    if(chl.length == 0){
                                        l.style.display = "none";
                                    }

                                    if(chl.length < 11 && chl.length > 0 ){
                                        l.style.height = chl.length * 30+"px";
                                    }

                                },false);
                                di2.addEventListener("click", function(){
                                    de.style.display = "none";
                                },false);
                            }, false);

                            if(chl.length < 10 && chl.length > 0 ){
                                l.style.height = chl.length * 30+"px";
                            }
                        }
                    }
                );
            }

            ge();

        }
    });
    return heatmap;
});


