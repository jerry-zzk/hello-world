define([
	'backbone',
	'common'
	], function(Backbone,url) {		
		var index = Backbone.View.extend({
     		el: 'map',
			initialize: function(name,id) {
       		
				this.render();
			},

			render: function() {
      
		    },
		    // remove:function(){

		    // }	
		});
		return index;	
	}
);