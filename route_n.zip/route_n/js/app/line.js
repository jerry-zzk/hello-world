define([
	'backbone',
	'common',
	'ol',
	'bootstrap'
], function(Backbone, urlss, ol, bootstrap) {
	var line = Backbone.View.extend({
		el: '#map',
		initialize: function(map, st, ed, id, phone, name, type) {
			window.map = map;
			this.map = map;
			this.st = (st != undefined && st != null) ? st : "1480770600";
			this.ed = (ed != undefined && ed != null) ? ed : "1480771800";

			window.node_id = this.node_id = (id != undefined && id != null) ? id : "";
			window.name = this.name = (name != undefined && name != null) ? name : "福建";
			window.type = this.type = (type != undefined && type != null) ? type : "";
			window.phone = this.phone = (phone != undefined && phone != null) ? phone : "";
			window.ol = ol;

			this.$el.append('<div id="popup"></div>');
			window.element = this.element = document.getElementById('popup');

			window.popup = this.popup = new ol.Overlay({
				element: this.element,
				positioning: 'bottom-center',
				stopEvent: false,
				offset: [0, -10]
			});
			//this.map.removeOverlay(this.popup);
			this.map.addOverlay(this.popup);
			$(this.element).popover('destroy');

			map.on("moveend",this.map_move,this);
			map.on("click", this.map_click,this);
			this.render();
			//window.flash = this.window_flash;
		},

		render: function() {
			this.remove();
			var name = this.name;
			var node_id = this.node_id;
			var phone = this.phone;
			var type = this.type;
			var st = this.st;
			var ed = this.ed;
			$.get(
				urlss.get_centerpoint + "name=" + this.name,
				function(data) {
					if (data.status == 0) {				
						// console.log(12);	
						map.setView(new ol.View({
							 center: ol.proj.fromLonLat([data.lng, data.lat]),
							  //center:[13279323.709641118,3008895.8453032863],
							zoom: 11
						}));
					}else{
						map.setView(new ol.View({
							// center: [12580502.955858162,3273023.9965427117],
							 center: [13279323.709641118,3008895.8453032863],
							zoom: 11
						}));	
					}
					var urls = urlss.get_station_line + "name=" + name +
						"&starttime=" + st +
						"&endtime=" + ed;
					if (node_id != "") {
						urls = urls + "&id=" + node_id;
					}
					if (phone != "") {
						urls = urls + "&phone=" + phone;
					}
					if (type != "") {
						if(type=="people"){
							type = 2;
						}
						if(type=="station"){
							type =1;
						}
						urls = urls + "&type=" + type;
						// console.log(type);
					}

					var extent1 = ol.proj.toLonLat(map.getView().calculateExtent(map.getSize()));
					var extent2 = ol.proj.toLonLat(map.getView().calculateExtent(map.getSize()).slice(-2));


					urls = urls + "&latstart=" + extent1[1] +
						"&latend=" + extent2[1] +
						"&lngstart=" + extent1[0] +
						"&lngend=" + extent2[0];


					var vectorLayer = new ol.layer.Vector({
						title: "line",
						source: new ol.source.Vector({
							loader: function() {
								var url = urls;
								var format = new ol.format.GeoJSON();
								var source = this;
								$.get(
									url,
									function(data) {
										var features = format.readFeatures(data, {
											featureProjection: 'EPSG:3857'
										});
										source.addFeatures(features);
										if (node_id != '' || phone != '') {

											map.getLayers().forEach(function(e, i) {
												if (e.get("title") == 'line') {
													if(e.getSource().getExtent()[0]!= Infinity)
														map.getView().fit(e.getSource().getExtent(), this.map.getSize());
												}
											});
										}
									},
									'json'
								);
							}
						}),
						style: function(feature) {
							if (feature.getGeometry().getType() === 'Point') {
								if (feature.get("type") == 2) {
									if (feature.get("c_fbs_status") == 0) {
										feature.setStyle(new ol.style.Style({
											image: new ol.style.Icon({
												anchor: [0.5, 1],
												src: '/route_n/image/is_close.png'
											})
										}));
									} else {
										feature.setStyle(new ol.style.Style({
											image: new ol.style.Icon({
												anchor: [0.5, 1],
												src: '/route_n/image/is_open.png'
											})
										}));
									}
								} else {
									feature.setStyle(new ol.style.Style({
										image: new ol.style.Icon({
											anchor: [0.5, 0.5],
											src: '/route_n/image/point.gif'
										})
									}));
								}
							} else {
								if (feature.get("type") == 2) {
									feature.setStyle(new ol.style.Style({
										stroke: new ol.style.Stroke({
											color: 'rgba(7,36,49,0.5)',
											lineCap: 'round',
											lineJoin: 'round',
											width: 5
										}),
									}));
								} else {
									feature.setStyle(new ol.style.Style({
										stroke: new ol.style.Stroke({
											color: 'rgba(34,180,235,0.5)',
											lineCap: 'round',
											lineJoin: 'round',
											width: 5
										})
									}));
								}
							}
						}
					});
					map.addLayer(vectorLayer);
				},
				'json'
			);


		},
		map_click: function(evt) {
			if(!window.popup){
				window.element  = document.getElementById('popup');

				window.popup  = new ol.Overlay({
					element: this.element,
					positioning: 'bottom-center',
					stopEvent: false,
					offset: [0, -10]
				});
				this.map.addOverlay(this.popup);
				
			}
			map.updateSize();
			var feature = map.forEachFeatureAtPixel(evt.pixel,
				function(feature) {
					return feature;
				}
			);


			var element = document.getElementById('popup');
      
            $("#popup").popover('destroy');
			if (feature&&feature.getGeometry().getType() == "Point") {
				
				var coordinates = ol.proj.fromLonLat([feature.get("c_longitude"),feature.get("c_latitude")]);
				var y = coordinates[1];
                var extent = map.getView().calculateExtent(map.getSize());
				var dy =parseInt( ((y - extent[3]) / (extent[1] - extent[3]))*map.getSize()[1]);
                var html = "";
				window.popup.setPosition(coordinates);
				if (feature.get('c_base_station_name') != undefined) {
					html = "<p>名称:" + feature.get('c_base_station_name') + "</p>" +
						"<p>地址:" + feature.get('c_address') + "</p>"+
						"<p>时间:"+new Date(parseInt(feature.get('c_timestamp')) * 1000).toLocaleString('chinses',{hour12:false}).replace(/年|月/g,"-").replace(/日/g," ").replace(/上午|下午/g," ")+"</p>";

				} else if (feature.get('c_msisdn') != undefined) {
					html = "<p>名称:" + feature.get('c_msisdn') + "</p>" +
						"<p>地址:" + feature.get('c_address') + "</p>"+
						"<p>时间:"+new Date(parseInt(feature.get('c_timestamp')) * 1000).toLocaleString('chinses',{hour12:false}).replace(/年|月/g,"-").replace(/日/g," ").replace(/上午|下午/g," ")+"</p>";
				}
			   if(dy< 120){
                    $(element).popover({
                        'placement': 'bottom',
                        'html': true,
                        'content': html
                    });
                }else{
                    $(element).popover({
                        'placement': 'top',
                        'html': true,
                        'animation': false,
                        'content': html
                    });
                }
                $(element).popover('show');
			} else {
				$(window.element).popover('hide');
				$(window.element).popover('destroy');
			}
		},
		map_move: function(e) {
			//if (this.node_id == '') {
				var name = this.name;
				var node_id = this.node_id;
				var phone = this.phone;
				var type = this.type;
				var st = this.st;
				var ed = this.ed;
				var urls = urlss.get_station_line + "name=" + name +
					"&starttime=" + st +
					"&endtime=" + ed;
				if (node_id != "") {
					urls = urls + "&id=" + node_id;
				}
				if (phone != "") {
					urls = urls + "&phone=" + phone;
				}
				if (type != "") {
					if(type=="people"){
							type = 2;
						}
						if(type=="station"){
							type = 1;
						}
						urls = urls + "&type=" + type;
						// console.log(type);
				}


				var extent1 = ol.proj.toLonLat(map.getView().calculateExtent(map.getSize()));
				var extent2 = ol.proj.toLonLat(map.getView().calculateExtent(map.getSize()).slice(-2));
				urls = urls + "&latstart=" + extent1[1] +
					"&latend=" + extent2[1] +
					"&lngstart=" + extent1[0] +
					"&lngend=" + extent2[0];


				var vectorLayer = new ol.layer.Vector({
					title: "line",
					source: new ol.source.Vector({
						loader: function() {
							var url = urls;
							var format = new ol.format.GeoJSON();
							var source = this;


							$.get(
								url,
								function(data) {
									var features = format.readFeatures(data, {
										featureProjection: 'EPSG:3857'
									});
									source.addFeatures(features);
									
									if(window.nodeid != node_id){
										window.flag = 0;
										window.nodeid = node_id;
									}
									if ((node_id != '' || phone != '') && window.flag != 1) {
										if(map.getView().getZoom()<=14){
											map.getLayers().forEach(function(e, i) {
												if (e.get("title") == 'line') {
													if(e.getSource().getExtent()[0]!= Infinity)
														map.getView().fit(e.getSource().getExtent(), this.map.getSize());
												}								
											});
											if(map.getView().getZoom()>14){
												map.getView().setZoom(14);
											}
											window.flag = 1;
										}else{
											map.getView().setZoom(14);
											window.flag = 1;
										}
										
									}
								},
								'json'
							);
						}
					}),
					style: function(feature) {
						// hide geoMarker if animation is active

						if (feature.getGeometry().getType() === 'Point') {
							if (feature.get("type") == 2) {
								if ( feature.get("c_fbs_status") == 0) {
									feature.setStyle(new ol.style.Style({
										image: new ol.style.Icon({
											anchor: [0.5, 1],
											src: '/route_n/image/is_close.png'
										})
									}));
								} else {
									feature.setStyle(new ol.style.Style({
										image: new ol.style.Icon({
											anchor: [0.5, 1],
											src: '/route_n/image/is_open.png'
										})
									}));
								}
							} else {
								feature.setStyle(new ol.style.Style({
									image: new ol.style.Icon({
										anchor: [0.5, 0.5],
										src: '/route_n/image/point.gif'
									})
								}));
							}
						} else {
							if (feature.get("type") == 2) {
								feature.setStyle(new ol.style.Style({
									stroke: new ol.style.Stroke({
										color: 'rgba(7,36,49,0.5)',
										lineCap: 'round',
										lineJoin: 'round',
										width: 5
									}),
								}));
							} else {
								feature.setStyle(new ol.style.Style({
									stroke: new ol.style.Stroke({
										color: 'rgba(34,180,235,0.5)',
										lineCap: 'round',
										lineJoin: 'round',
										width: 5
									})
								}));
							}
						}
					}
				});
				this.remove();
				map.addLayer(vectorLayer);
			//}
		},
		remove: function() {
			map.getLayers().forEach(function(e, i) {
				if (e.get("title")) {
					map.removeLayer(e);
				}
			});
			
		}
	});
	return line;
});