define([
	'backbone',
	'd3'
	], function(Backbone,d3) {

		model = Backbone.Model.extend({
			url:'../../data/data.json',
	        initialize: function(){
	            
	        },
	        defaults: {
	           
	        }
	    });
	    return model;
	}
);