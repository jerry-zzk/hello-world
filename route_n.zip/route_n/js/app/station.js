define([
    'backbone',
    'common',
    'ol',
    'bootstrap',
    'cluster',
    'select_cluster'
], function (Backbone, urls, ol, bootstrap) {
    var station = Backbone.View.extend({


        el: '#map',
        initialize: function (map, start_time, end_time, name, id, phone, type){

            //debugger;
            window.urls = urls;
            window.ol = ol;
            this.map = map;
            this.name = (name !== undefined && name !== null) ? name : "湖南";

            this.node_id = (id != undefined && id != null) ? id : "";
            this.type = (type != undefined && type != null) ? type : "";
            this.phone = (phone != undefined && phone != null) ? phone : "";
            this.$el.append('<div id="popup"></div>');
            window.element =  document.getElementById('popup');

            console.log(this.name);

            window.popup = this.popup = new ol.Overlay({
                element: window.element,
                positioning: 'bottom-center',
                stopEvent: false,
                offset: [0, -10]
            });

            this.map.removeOverlay(this.popup);
            this.map.addOverlay(this.popup);

            $(this.element).popover('destroy');
            if (start_time !== undefined && start_time !== null && end_time !== undefined && end_time !== null) {

                this.st = start_time;
                this.ed = end_time;
                //

                this.render();

            } else { 
                this.re();
            }
            //this.map_move(this);
            map.on("moveend", this.map_move, this);
            map.on("click", this.map_click, this);
            console.log(this.re);

        },
        re: function () {
            function refresh(th){

                //console.log(th);
                th.remove();
                th.ed = end_time = parseInt(new Date().getTime()/1000);
                th.st = start_time = end_time - 5*60;
                //th.ed = 1482229300;
                //th.st = 1482229100;

                //
                // th.$el.append('<div id="popup"></div>');
                // window.element = th.element = document.getElementById('popup');

                // window.popup = th.popup = new ol.Overlay({
                //     element: th.element,
                //     positioning: 'bottom-center',
                //     stopEvent: false,
                //     offset: [0, -10]
                // });

                // th.map.removeOverlay(th.popup);
                // th.map.addOverlay(th.popup);
                //$(th.element).popover('destroy');


                th.render();
            }
            refresh(this);
            setInterval(refresh,1000*300,(this));
            // refresh(this);
            // setInterval(refresh,1000*300,(this));
        },
        render: function () {
            this.remove();

            var name = this.name;

            var node_id = this.node_id;
            var phone = this.phone;
            var type = this.type;

            //
            var st = this.st;
            var ed = this.ed;

            //debugger;
            $.get(
                urls.get_centerpoint + "name=" + this.name,
                function (data) {
                    if (data.status == 0) {
                        //console.log(124);
                        //console.log(data);
                        map.setView(new ol.View({
                            center: ol.proj.fromLonLat([data.lng, data.lat]),
                            zoom: 10
                        }));
                    } else {
                        map.setView(new ol.View({
                            // center: [12580502.955858162, 3273023.9965427117],
                            center: [13279323.709641118,3008895.8453032863],
                            zoom: 10
                        }));
                    }
//debugger;
                    var urls = window.urls.get_station + "name=" + name + "&starttime=" + st + "&endtime=" + ed;

                    if (node_id != "") {
                        urls = urls + "&id=" + node_id;
                    }
                    if (phone != "") {
                        urls = urls + "&phone=" + phone;
                    }
                    if (type != "") {
                        urls = urls + "&type=" + type;
                    }

                    var extent1 = ol.proj.toLonLat(map.getView().calculateExtent(map.getSize()));
                    var extent2 = ol.proj.toLonLat(map.getView().calculateExtent(map.getSize()).slice(-2));


                    urls = urls + "&latstart=" + extent1[1] +
                        "&latend=" + extent2[1] +
                        "&lngstart=" + extent1[0] +
                        "&lngend=" + extent2[0];


                    var vectorLayer = new ol.layer.Vector({
                        title: "geo_polygon",
                        source: new ol.source.Vector({
                            loader: function () {
                                var url = urls;
                                var format = new ol.format.GeoJSON();
                                var source = this;
                                $.get(
                                    url,
                                    function (data) {
                                        var features = format.readFeatures(data, {
                                            featureProjection: 'EPSG:3857'
                                        });
                                        source.addFeatures(features);
                                    },
                                    'json'
                                );
                            }
                        }),
                        style: function (feature) {
                            if (feature.getGeometry().getType() === 'Point') {
                                if (feature.get("type") == 2) {
                                    if (feature.get("c_fbs_status") == 0) {
                                        feature.setStyle(new ol.style.Style({
                                            image: new ol.style.Icon({
                                                anchor: [0.5, 1],
                                                src: '/route_n/image/is_close.png'
                                            })
                                        }));
                                    } else {
                                        feature.setStyle(new ol.style.Style({
                                            image: new ol.style.Icon({
                                                anchor: [0.5, 1],
                                                src: '/route_n/image/is_open.png'
                                            })
                                        }));
                                    }
                                } else {

                                    feature.setStyle(new ol.style.Style({
                                        image: new ol.style.Icon({
                                            anchor: [0.5, 0.5],
                                            src: '/route_n/image/point.gif'
                                        })
                                    }));

                                }
                            } else {
                                if (feature.get("type") == 2) {
                                    feature.setStyle(new ol.style.Style({
                                        stroke: new ol.style.Stroke({
                                            color: 'rgba(7,36,49,0.5)',
                                            lineCap: 'round',
                                            lineJoin: 'round',
                                            width: 5
                                        }),
                                    }));
                                } else {
                                    feature.setStyle(new ol.style.Style({
                                        stroke: new ol.style.Stroke({
                                            color: 'rgba(34,180,235,0.5)',
                                            lineCap: 'round',
                                            lineJoin: 'round',
                                            width: 5
                                        })
                                    }));
                                }
                            }
                        }
                    });
                    map.addLayer(vectorLayer);


                    //热力图
                    var heatmap = new ol.layer.Heatmap({
                        source: new ol.source.Vector({
                            loader: function () {
                                var url = urls;
                                var format = new ol.format.GeoJSON();
                                var source = this;
                                $.get(
                                    url,
                                    function (data) {
                                        var features = format.readFeatures(data, {
                                            featureProjection: 'EPSG:3857'
                                        });
                                        source.addFeatures(features);
                                        //if (node_id != '' || phone != '') {
                                        //
                                        //    map.getLayers().forEach(function (e, i) {
                                        //        if (e.get("title") == 'line') {
                                        //            if (e.getSource().getExtent()[0] != Infinity)
                                        //                map.getView().fit(e.getSource().getExtent(), this.map.getSize());
                                        //        }
                                        //    });
                                        //}
                                    }
                                );
                            }
                        })
                    });
                    map.addLayer(heatmap);
                },
                'json'
            );
        },
        map_click: function (evt) {

            map.updateSize();
            var feature = map.forEachFeatureAtPixel(evt.pixel,
                function (feature) {
                    return feature;
                }
            );
            var element = document.getElementById('popup');

            $("#popup").popover('destroy');
            if (feature && feature.getGeometry().getType() == "Point") {


                var coordinates = ol.proj.fromLonLat([feature.get("c_longitude"),feature.get("c_latitude")]);
                var y = coordinates[1];
                var extent = map.getView().calculateExtent(map.getSize());
                window.popup.setPosition(coordinates);
                var dy =parseInt( ((y - extent[3]) / (extent[1] - extent[3]))*map.getSize()[1]);
                var html = "";
                if (feature.get('c_base_station_name') != undefined) {
                    html = "<p>名称:" + feature.get('c_base_station_name') + "</p>" +
                        "<p>地址:" + feature.get('c_address') + "</p>" +
                        "<p>时间:" + new Date(parseInt(feature.get('c_timestamp')) * 1000).toLocaleString().replace(/年|月/g,"-").replace(/日/g," ") + "</p>";

                } else if (feature.get('c_msisdn') != undefined) {
                    html = "<p>名称:" + feature.get('c_msisdn') + "</p>" +
                        "<p>地址:" + feature.get('c_address') + "</p>" +
                        "<p>时间:" + new Date(parseInt(feature.get('c_timestamp')) * 1000).toLocaleString().replace(/年|月/g,"-").replace(/日/g," ") + "</p>";
                }
                //if ($(".popover-content").length == 0) {

                if(dy< 120){
                    $(element).popover({
                        'placement': 'bottom',
                        'html': true,
                        'content': html
                    });
                }else{
                    $(element).popover({
                        'placement': 'top',
                        'html': true,
                        'animation': false,
                        'content': html
                    });
                }
                $(element).popover('show');
                // } else {
                //     //$(".popover-content").html(html);
                //     if(dy< 120){

                //         $(element).popover({
                //             'placement': 'bottom',
                //             'html': true,
                //             'content': html
                //         });
                //     }else{
                //         $(element).popover({
                //             'placement': 'top',
                //             'html': true,
                //             'content': html
                //         });
                //     }
                //     $(element).popover('show');
                //     // debugger

                // }
            }
        },
        map_move: function (e) {
            //if (this.node_id == '') {
            //console.log(13123);
            var name = this.name;
            var node_id = this.node_id;
            var phone = this.phone;
            var type = this.type;
            var st = this.st;
            var ed = this.ed;
            var urls = window.urls.get_station + "name=" + name +
                "&starttime=" + st +
                "&endtime=" + ed;
            if (node_id != "") {
                urls = urls + "&id=" + node_id;
            }
            if (phone != "") {
                urls = urls + "&phone=" + phone;
            }
            if (type != "") {
                urls = urls + "&type=" + type;
            }

            var extent1 = ol.proj.toLonLat(map.getView().calculateExtent(map.getSize()));
            var extent2 = ol.proj.toLonLat(map.getView().calculateExtent(map.getSize()).slice(-2));


            urls = urls + "&latstart=" + extent1[1] +
                "&latend=" + extent2[1] +
                "&lngstart=" + extent1[0] +
                "&lngend=" + extent2[0];

            var vectorLayer = new ol.layer.Vector({
                title: "geo_polygon",
                source: new ol.source.Vector({
                    loader: function () {
                        var url = urls;
                        var format = new ol.format.GeoJSON();
                        var source = this;


                        $.get(
                            url,
                            function (data) {
                                var features = format.readFeatures(data, {
                                    featureProjection: 'EPSG:3857'
                                });
                                source.addFeatures(features);
                                if (node_id != '' || phone != '') {

                                    map.getLayers().forEach(function (e, i) {
                                        if (e.get("title") == 'line') {
                                            if (e.getSource().getExtent()[0] != Infinity)
                                                map.getView().fit(e.getSource().getExtent(), this.map.getSize());
                                        }
                                    });
                                }
                            },
                            'json'
                        );
                    }
                }),
                style: function (feature) {
                    // hide geoMarker if animation is active

                    if (feature.getGeometry().getType() === 'Point') {
                        if (feature.get("type") == 2) {
                            if (feature.get("c_fbs_status") == 0) {
                                feature.setStyle(new ol.style.Style({
                                    image: new ol.style.Icon({
                                        anchor: [0.5, 1],
                                        src: '/route/image/is_close.png'
                                    })
                                }));
                            } else {
                                feature.setStyle(new ol.style.Style({
                                    image: new ol.style.Icon({
                                        anchor: [0.5, 1],
                                        src: '/route/image/is_open.png'
                                    })
                                }));
                            }
                        } else {

                            //openlayer3 写法
                            //
                            //var point_div = document.createElement("div");
                            //point_div.id = "cs";
                            ////console.log(point_div);
                            //var point_overlay = new ol.Overlay({
                            //    element: point_div,
                            //    positioning: 'center-center'
                            //});
                            //map.addOverlay(point_overlay);
                            //point_overlay.setPosition(ol.proj.fromLonLat([feature.get("c_longitude"),feature.get("c_latitude")]));
                            //console.log(ol.proj.fromLonLat([feature.get("c_longitude"),feature.get("c_latitude")]));
                            //console.log([feature.get("c_longitude"),feature.get("c_latitude")]);


                            //插入图片
                            //feature.setStyle(new ol.style.Style({
                            //    image:new ol.style.Icon({
                            //        anchor:[0.5,0.5],
                            //        src:"/route/image/point.gif"
                            //    })
                            //}));
                        }
                    } else {
                        if (feature.get("type") == 2) {
                            feature.setStyle(new ol.style.Style({
                                stroke: new ol.style.Stroke({
                                    color: 'rgba(7,36,49,0.5)',
                                    lineCap: 'round',
                                    lineJoin: 'round',
                                    width: 5
                                })
                            }));
                        } else {
                            feature.setStyle(new ol.style.Style({
                                stroke: new ol.style.Stroke({
                                    color: 'rgba(34,180,235,0.5)',
                                    lineCap: 'round',
                                    lineJoin: 'round',
                                    width: 5
                                })
                            }));
                        }
                    }
                }
            });
            this.remove();
            map.addLayer(vectorLayer);

            //}
        },
        remove: function () {
            map.getLayers().forEach(function (e, i) {
                if (e.get("title")) {
                    //console.log("delete station");
                    map.removeLayer(e);
                }
            });
        }
    });
    return station;
});