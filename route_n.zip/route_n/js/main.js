requirejs.config({
    //路径依照html的相对路径
    baseUrl: './js', //assets
    //清除缓存
    urlArgs: "bust=" + (new Date()).getTime(),
    //路径依照baseUrl的相对路径 结尾不加.js
    paths: {

        jquery: './lib/jquery.min',
        ol3: './lib/ol3/ol3-ext',
        underscore: './lib/underscore_debug',
        backbone: './lib/backbone',
        ol: './lib/ol3/ol-debug',
        bootstrap:'./lib/bootstrap/js/bootstrap.min',
        cluster:'./lib/ol3/animatedclusterlayer',
        select_cluster:"./lib/ol3/selectclusterinteraction",

        router: './app/router',
        index: './app/index',
        line:'./app/line',
        geo_polygon:'./app/geo_polygon',
        station:'./app/station',
        heatmap: './app/heatmap',
        heat: './app/heat',
        common: './app/common'
    },
    shim: {
        'underscore': {
            exports: '_'
        },
        'backbone': {
            deps: [
                'underscore',
                'jquery'
            ],
            exports: 'Backbone'
        },
        bootstrap:{
            deps: [
                'jquery'
            ],
        },
        'ol':{
            exports: 'ol'
        },
        'cluster':{
            deps:['ol'],
            exports: 'cluster'
        },
        'select_cluster':{
            deps:['ol'],
            exports: 'select_cluster'
        },
        'ol3':{
            deps:['ol']
        }
    }
});

requirejs([
    'jquery',
    'router',
], function($, router) {
    var app_router = new router();
    Backbone.history.start();
});